package com.cg.Lab2.bean;

public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number:" + args[0]);
		if(Integer.parseInt(args[0])< 0)
			{
			System.out.println("negative number");
			}
		else
			{
			System.out.println("postive number");
			}
					

	}

}
