package com.cg.mra.exception;

public class MobileRechargeException extends Exception {
	
	public MobileRechargeException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
