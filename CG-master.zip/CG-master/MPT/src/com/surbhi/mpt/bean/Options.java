package com.surbhi.mpt.bean;

public enum Options {
	byName, byId;
}
