package com.cg.Lab2project.ui;

import com.cg.Lab2.bean.Mperson;

public class Mpersonproject {

	public static void main(String[] args) {
		
		Mperson p= new Mperson("Aditi","Priya",'f');
		p.getnumber(1234506789);
		p.display();
		

	}

}
