package com.capgemini.salesmanagement.exception;

public class ProductPriceException extends Exception {

	public ProductPriceException(String string) {
super();
	}

}
