package com.capgemini.salesmanagement.exception;

public class ProductQuantityException extends Exception{

	public ProductQuantityException(String string) {
		super();
	}

}
