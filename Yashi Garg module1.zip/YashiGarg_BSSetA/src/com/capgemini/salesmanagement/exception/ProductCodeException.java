package com.capgemini.salesmanagement.exception;

public class ProductCodeException extends Exception {

	public ProductCodeException(String string) {
		super();
	}

}
