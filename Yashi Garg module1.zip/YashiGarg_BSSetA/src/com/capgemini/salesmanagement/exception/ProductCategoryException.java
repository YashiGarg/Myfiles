package com.capgemini.salesmanagement.exception;

public class ProductCategoryException extends Exception{

	public ProductCategoryException(String string) {
  super();
	}

}
