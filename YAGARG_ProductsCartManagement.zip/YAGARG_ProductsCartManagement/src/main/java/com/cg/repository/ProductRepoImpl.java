package com.cg.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.Product;
import com.cg.exception.ProductIdIsNotFoundException;

@Transactional
@Repository("productRepo")
public class ProductRepoImpl implements IProductRepo {
	@PersistenceContext
	EntityManager entitymanager;

	public EntityManager getEntitymanager() {
		return entitymanager;
	}

	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}

	@Override
	public Product createProduct(Product product) {
		entitymanager.persist(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public Product updateProduct( String productId,double productPrice) throws ProductIdIsNotFoundException {
		Product product = entitymanager.find(Product.class, productId);
		if(product==null)
			throw new ProductIdIsNotFoundException("Id is not present");
		product.setPrice(productPrice);
		entitymanager.persist(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public Product deleteProduct(String productId) throws ProductIdIsNotFoundException {
		Product product = entitymanager.find(Product.class, productId);
		if(product==null)
			throw new ProductIdIsNotFoundException("Id is not present");
		entitymanager.remove(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public List<Product> viewProductList() {
		TypedQuery<Product> query = entitymanager.createQuery("select products from Product products ", Product.class);

		List<Product> list = query.getResultList();
		return list;
	}

	@Override
	public Product findProduct(String productId) throws ProductIdIsNotFoundException {
		Product product = entitymanager.find(Product.class, productId);
		if(product==null)
			throw new ProductIdIsNotFoundException("Id is not present");
		product.setId(productId);
		return product;
	}

	@Override
	public Product updateProduct(Product product) {
		entitymanager.merge(product);
		entitymanager.flush();
		return product;
	}

}
