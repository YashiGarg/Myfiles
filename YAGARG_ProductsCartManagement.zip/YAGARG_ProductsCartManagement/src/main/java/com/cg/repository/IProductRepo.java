package com.cg.repository;

import java.util.List;

import com.cg.beans.Product;
import com.cg.exception.ProductIdIsNotFoundException;

public interface IProductRepo {
	public Product createProduct(Product product);

	public Product updateProduct(Product product);

	public Product deleteProduct(String productId) throws ProductIdIsNotFoundException;

	public List<Product> viewProductList();

	public Product findProduct(String productId) throws ProductIdIsNotFoundException;


	public Product updateProduct(String productId,double productPrice) throws ProductIdIsNotFoundException;
}
