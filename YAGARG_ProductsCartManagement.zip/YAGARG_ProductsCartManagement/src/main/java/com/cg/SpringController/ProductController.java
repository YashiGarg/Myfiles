package com.cg.SpringController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;

import com.cg.exception.ProductIdIsNotFoundException;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService productService;

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	@RequestMapping(value = "/products", method = RequestMethod.POST, produces = "application/json")
	public Product createProduct(@RequestBody Product product) {
		return productService.createProduct(product);

	}

	@RequestMapping(path = "/products", method = RequestMethod.PUT, produces = "application/json")
	public Product UpdateProduct(@RequestBody Product product) {
		return productService.updateProduct(product);
	}

	@RequestMapping(path = "/products/{productId}", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
	public Product deleteProduct(@PathVariable String productId) throws ProductIdIsNotFoundException {
		Product product = productService.deleteProduct(productId);
		return product;
	}

	@RequestMapping(path = "/products/{productId}/{productPrice}", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public Product updateProduct(@PathVariable String productId, @PathVariable double productPrice) throws ProductIdIsNotFoundException {
		Product product = productService.updateProduct(productId, productPrice);
		return product;

	}

	@RequestMapping(path = "/products", produces = "application/json", method = RequestMethod.GET)
	public List<Product> viewProductList() {
		List<Product> list = productService.viewProductList();
		return list;

	}

	@RequestMapping(path = "/products/{productId}", produces = "application/json")
	public Product findProduct(@PathVariable String productId) throws ProductIdIsNotFoundException {
		Product product = productService.findProduct(productId);
		return product;

	}
	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "carNo is not found")
	@ExceptionHandler({ ProductIdIsNotFoundException.class })
	public void handleException() {

	}
}