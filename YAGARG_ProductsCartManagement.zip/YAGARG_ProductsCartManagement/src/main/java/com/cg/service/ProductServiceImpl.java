package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.Product;
import com.cg.exception.ProductIdIsNotFoundException;
import com.cg.repository.IProductRepo;

@Transactional
@Service("productService")
public class ProductServiceImpl implements IProductService {
	IProductRepo productRepo;

	public IProductRepo getProductRepo() {
		return productRepo;
	}

	public void setProductRepo(IProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	@Override
	public Product createProduct(Product product) {

		return productRepo.createProduct(product);
	}

	@Override
	public Product updateProduct(String productId,double productPrice) throws ProductIdIsNotFoundException {

		return productRepo.updateProduct( productId,productPrice);
	}

	@Override
	public Product deleteProduct(String productId) throws ProductIdIsNotFoundException {

		return productRepo.deleteProduct(productId);
	}

	@Override
	public List<Product> viewProductList() {

		return productRepo.viewProductList();
	}

	@Override
	public Product findProduct(String productId) throws ProductIdIsNotFoundException {

		return productRepo.findProduct(productId);
	}

	@Override
	public Product updateProduct(Product product) {
		
		return productRepo.updateProduct(product);
	}

}
