package com.cg.exception;

public class ProductIdIsNotFoundException extends Exception {

	public ProductIdIsNotFoundException(String message) {
		super(message);
	}
}
